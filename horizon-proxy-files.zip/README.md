# Horizon proxy backend

This is a minimal server-side fetch proxy for the Web Proxy card added to `misc.html`.

## Important limitations
- A server-side proxy must be deployed separately; GitHub Pages only hosts static files.
- This backend uses an explicit destination allowlist to avoid becoming an unrestricted public proxy.
- It returns upstream response bytes. Complex websites may not work because relative links, scripts, cookies, WebSockets, and site security policies are not rewritten.
- Do not deploy this publicly without adding authentication, request limits, logging/privacy choices, and stronger network-level SSRF protections.
- Use only for sites you are permitted to access. It is not designed to bypass access controls.

## Run locally
Requires Node.js 20 or newer.

```sh
npm start
```

By default, only `example.com` and `www.example.com` are allowed. Set `ALLOWED_HOSTS` to a comma-separated list of hostnames you intend to test, for example:

```sh
ALLOWED_HOSTS=example.com,www.example.com npm start
```

The server listens on port 8080. In the Horizon Web Proxy card, enter:
- Proxy server URL: `http://localhost:8080`
- Website URL: `https://example.com`

To use it from a GitHub Pages site, deploy the backend to a server you control, then enter that deployed HTTPS URL in the Proxy server field. Don't use `localhost` from GitHub Pages; it refers to the visitor's own device.
